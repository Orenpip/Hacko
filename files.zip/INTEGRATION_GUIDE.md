# Step-by-Step Integration Guide

This guide will walk you through integrating the file upload feature into your Canvas addon.

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Access to Canvas LMS as an administrator
- A server to host your addon (can be localhost for development)

## Step 1: Setup Your Project

1. **Clone or navigate to your Hacko repository:**
```bash
cd /path/to/Hacko
```

2. **Copy the file upload files to your project:**
```bash
# Copy frontend files
cp file-upload-component.html /path/to/Hacko/public/
cp file-upload.js /path/to/Hacko/public/js/
cp canvas-lti-integration.js /path/to/Hacko/public/js/

# Copy backend files
cp upload-api.js /path/to/Hacko/routes/
cp server.js /path/to/Hacko/
cp package.json /path/to/Hacko/
```

3. **Install dependencies:**
```bash
npm install
```

4. **Create uploads directory:**
```bash
mkdir uploads
```

5. **Setup environment variables:**
```bash
cp .env.example .env
# Edit .env with your actual values
```

## Step 2: Integrate with Your Existing Code

### Option A: Standalone Page

If you want the upload feature as a separate page:

1. **Update your routing** (if using Express):
```javascript
// In your main app.js or routes file
app.get('/upload', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'file-upload-component.html'));
});
```

2. **Add a link in your Canvas addon navigation:**
```html
<a href="/upload">Upload Documents</a>
```

### Option B: Embedded in Existing Page

If you want to embed it in an existing page:

1. **In your main HTML file:**
```html
<div id="upload-section">
    <!-- Copy the content from file-upload-component.html -->
    <!-- Or use an iframe: -->
    <iframe src="/upload" width="100%" height="600px" frameborder="0"></iframe>
</div>
```

2. **Include the scripts:**
```html
<script src="/js/file-upload.js"></script>
<script src="/js/canvas-lti-integration.js"></script>
```

## Step 3: Configure Canvas LTI

### 3.1 Create Developer Key in Canvas

1. Log in to Canvas as an admin
2. Go to **Admin → Developer Keys**
3. Click **+ Developer Key** → **+ LTI Key**

### 3.2 Fill in LTI Configuration

**Key Settings:**
- **Key Name**: Hacko File Upload
- **Redirect URIs**: `https://your-domain.com/lti/callback`
- **Method**: Manual Entry
- **Title**: Upload Resume & Transcript
- **Description**: Upload and manage student documents
- **Target Link URI**: `https://your-domain.com/upload`
- **OpenID Connect Initiation Url**: `https://your-domain.com/lti/login`

**Placements:**
- ☑️ Course Navigation
- ☑️ Assignment Selection
- ☑️ Link Selection

**Privacy:**
- ☑️ Public
- Include name
- Include email

**Scopes:**
Select these scopes:
```
url:POST|/api/v1/courses/:course_id/files
url:GET|/api/v1/courses/:course_id/files
url:GET|/api/v1/users/:user_id/files
```

4. Click **Save**
5. Note your **Client ID** - you'll need this

### 3.3 Enable the Key

1. After saving, find your new key in the list
2. Click the **ON** toggle to enable it

## Step 4: Add LTI Tool to Course

1. Go to your Canvas course
2. **Settings → Apps**
3. Click **+ App**
4. Configuration Type: **By Client ID**
5. Enter your Client ID from Step 3.2
6. Click **Submit**

## Step 5: Test the Integration

### 5.1 Start Your Server

```bash
npm start
```

### 5.2 Access from Canvas

1. In your Canvas course navigation, you should now see "Upload Resume & Transcript"
2. Click it to launch your addon
3. Try uploading a test file

### 5.3 Verify Upload

Check that:
- ✅ Files are being uploaded to the `/uploads` directory
- ✅ No console errors in browser
- ✅ Server logs show successful upload
- ✅ File size and type validation works

## Step 6: Database Integration (Optional)

If you want to persist file metadata in a database:

### 6.1 Create Database Schema

**PostgreSQL Example:**
```sql
CREATE TABLE uploaded_files (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    course_id VARCHAR(255),
    file_type VARCHAR(50) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INTEGER NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_user_id ON uploaded_files(user_id);
CREATE INDEX idx_course_id ON uploaded_files(course_id);
```

### 6.2 Update upload-api.js

Install a database driver:
```bash
npm install pg  # for PostgreSQL
# or
npm install mysql2  # for MySQL
# or
npm install mongodb  # for MongoDB
```

Then update the `saveFileRecords` function in `upload-api.js`.

## Step 7: Security Hardening

### 7.1 Add File Scanning

Install ClamAV or similar:
```bash
npm install clamscan
```

Update upload-api.js:
```javascript
const NodeClam = require('clamscan');

// In the upload endpoint, before saving:
const clamscan = await new NodeClam().init();
const { isInfected } = await clamscan.scanFile(file.path);
if (isInfected) {
    fs.unlinkSync(file.path);
    throw new Error('File contains malware');
}
```

### 7.2 Add Rate Limiting

```bash
npm install express-rate-limit
```

In server.js:
```javascript
const rateLimit = require('express-rate-limit');

const uploadLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // limit each user to 10 uploads per window
    message: 'Too many uploads, please try again later'
});

app.use('/api/upload', uploadLimiter);
```

### 7.3 Add Authentication Middleware

```javascript
// middleware/auth.js
function validateCanvasToken(req, res, next) {
    const token = req.headers.authorization;
    // Validate token with Canvas
    // If valid, proceed; otherwise, return 401
    next();
}

// In upload-api.js
router.post('/upload', validateCanvasToken, upload.fields([...]), async (req, res) => {
    // ...
});
```

## Step 8: Deploy to Production

### 8.1 Choose a Hosting Provider

Options:
- **Heroku**: Easy deployment, free tier available
- **AWS EC2/Elastic Beanstalk**: Scalable, reliable
- **DigitalOcean**: Simple, cost-effective
- **Vercel/Netlify**: For static frontend (need separate backend)

### 8.2 Configure Environment

1. Set production environment variables
2. Use HTTPS (required for Canvas LTI)
3. Configure CORS for your Canvas domain
4. Set up proper logging

### 8.3 Deploy

**Heroku Example:**
```bash
# Install Heroku CLI
heroku login
heroku create your-app-name

# Set environment variables
heroku config:set NODE_ENV=production
heroku config:set CANVAS_DOMAIN=https://your-canvas.instructure.com

# Deploy
git push heroku main
```

### 8.4 Update Canvas Configuration

Update your Developer Key settings with production URLs:
- Redirect URIs: `https://your-app.herokuapp.com/lti/callback`
- Target Link URI: `https://your-app.herokuapp.com/upload`

## Step 9: Monitor and Maintain

### 9.1 Set Up Logging

```bash
npm install winston
```

```javascript
const winston = require('winston');

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});
```

### 9.2 Monitor Usage

Track:
- Number of uploads per day
- File sizes
- Error rates
- Popular file types

### 9.3 Regular Maintenance

- Clean up old files
- Update dependencies
- Review security logs
- Backup database

## Troubleshooting

### Issue: "CORS Error"
**Solution:** 
- Verify CORS configuration in server.js
- Add your Canvas domain to allowed origins

### Issue: "File too large"
**Solution:**
- Check MAX_FILE_SIZE in .env
- Update limits in both frontend and backend

### Issue: "LTI launch failed"
**Solution:**
- Verify Developer Key is enabled
- Check redirect URIs match exactly
- Review Canvas error logs

### Issue: "Files not saving"
**Solution:**
- Check uploads directory permissions
- Verify disk space
- Review server logs

## Next Steps

1. ✅ Test with real users
2. ✅ Gather feedback
3. ✅ Add analytics
4. ✅ Implement additional features:
   - File preview
   - Resume parsing
   - Transcript analysis
   - File sharing with instructors

## Support

If you encounter issues:
1. Check the README.md
2. Review server and browser console logs
3. Test with smaller files
4. Verify all environment variables are set

Good luck with your Canvas addon integration!
