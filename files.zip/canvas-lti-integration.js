// Canvas LTI Integration for File Upload Component
// This file shows how to integrate the file upload component with Canvas LTI

class CanvasLTIIntegration {
    constructor() {
        this.ltiData = null;
        this.init();
    }

    async init() {
        // Get LTI launch data from Canvas
        this.ltiData = await this.getLTIData();
        
        // Initialize the file upload component with Canvas context
        this.initializeFileUpload();
    }

    async getLTIData() {
        // Canvas provides LTI data through various methods
        // This could come from URL parameters, postMessage, or API calls
        
        // Example: Getting data from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        
        return {
            userId: urlParams.get('user_id') || this.getUserIdFromSession(),
            courseId: urlParams.get('course_id'),
            contextId: urlParams.get('context_id'),
            contextLabel: urlParams.get('context_label'),
            contextTitle: urlParams.get('context_title'),
            userEmail: urlParams.get('lis_person_contact_email_primary'),
            userName: urlParams.get('lis_person_name_full'),
            roles: urlParams.get('roles')?.split(',') || []
        };
    }

    getUserIdFromSession() {
        // Fallback to session storage or localStorage
        return sessionStorage.getItem('canvas_user_id') || 
               localStorage.getItem('canvas_user_id') || 
               'guest_user';
    }

    initializeFileUpload() {
        // Override the FileUploadManager to use Canvas context
        const originalHandleSubmit = FileUploadManager.prototype.handleSubmit;
        
        FileUploadManager.prototype.handleSubmit = async function() {
            const submitButton = document.getElementById('submitButton');
            submitButton.disabled = true;
            submitButton.textContent = 'Uploading...';

            try {
                const formData = new FormData();
                
                if (this.resumeFile) {
                    formData.append('resume', this.resumeFile);
                }
                
                if (this.transcriptFile) {
                    formData.append('transcript', this.transcriptFile);
                }

                // Add Canvas LTI context
                const integration = window.canvasLTIIntegration;
                formData.append('userId', integration.ltiData.userId);
                formData.append('courseId', integration.ltiData.courseId);
                formData.append('contextId', integration.ltiData.contextId);
                formData.append('userEmail', integration.ltiData.userEmail);
                formData.append('userName', integration.ltiData.userName);
                formData.append('uploadDate', new Date().toISOString());

                const response = await this.uploadFiles(formData);

                if (response.success) {
                    this.showSuccess();
                    
                    // Notify Canvas of successful upload
                    integration.notifyCanvas('files_uploaded', response.data);
                    
                    setTimeout(() => {
                        this.resetForm();
                    }, 2000);
                } else {
                    throw new Error(response.message || 'Upload failed');
                }

            } catch (error) {
                alert('Upload failed: ' + error.message);
                submitButton.disabled = false;
                submitButton.textContent = 'Upload Documents';
            }
        };
    }

    notifyCanvas(event, data) {
        // Send message to Canvas parent frame
        if (window.parent && window.parent !== window) {
            window.parent.postMessage({
                subject: 'lti.file_upload',
                event: event,
                data: data,
                context: this.ltiData
            }, '*'); // In production, specify the Canvas domain
        }
    }

    // Canvas API integration methods
    async getCanvasUserProfile() {
        // Fetch user profile from Canvas API
        const canvasApiUrl = '/api/v1/users/self/profile';
        
        try {
            const response = await fetch(canvasApiUrl, {
                headers: {
                    'Authorization': `Bearer ${this.getCanvasAccessToken()}`
                }
            });
            
            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.error('Error fetching Canvas user profile:', error);
        }
        
        return null;
    }

    async submitToCanvasAssignment(assignmentId, fileUrls) {
        // Submit uploaded files to a Canvas assignment
        const canvasApiUrl = `/api/v1/courses/${this.ltiData.courseId}/assignments/${assignmentId}/submissions`;
        
        try {
            const response = await fetch(canvasApiUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.getCanvasAccessToken()}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    submission: {
                        submission_type: 'online_upload',
                        file_ids: fileUrls
                    }
                })
            });
            
            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.error('Error submitting to Canvas assignment:', error);
        }
        
        return null;
    }

    getCanvasAccessToken() {
        // Retrieve Canvas access token from secure storage
        // This should be stored securely after OAuth flow
        return sessionStorage.getItem('canvas_access_token');
    }

    // Store uploaded file references in Canvas
    async storeFileInCanvasUserFiles(file, fileUrl) {
        // Upload file to Canvas user files
        const canvasApiUrl = `/api/v1/users/${this.ltiData.userId}/files`;
        
        try {
            // Step 1: Tell Canvas we're going to upload a file
            const response1 = await fetch(canvasApiUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.getCanvasAccessToken()}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: file.name,
                    size: file.size,
                    content_type: file.type,
                    parent_folder_path: '/uploads/documents'
                })
            });
            
            if (!response1.ok) {
                throw new Error('Failed to initiate file upload to Canvas');
            }
            
            const uploadData = await response1.json();
            
            // Step 2: Upload the actual file
            const formData = new FormData();
            Object.keys(uploadData.upload_params).forEach(key => {
                formData.append(key, uploadData.upload_params[key]);
            });
            formData.append('file', file);
            
            const response2 = await fetch(uploadData.upload_url, {
                method: 'POST',
                body: formData
            });
            
            if (response2.ok) {
                return await response2.json();
            }
        } catch (error) {
            console.error('Error storing file in Canvas:', error);
        }
        
        return null;
    }
}

// Initialize Canvas LTI integration when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.canvasLTIIntegration = new CanvasLTIIntegration();
});

// Listen for messages from Canvas
window.addEventListener('message', (event) => {
    // Verify the message is from Canvas
    // In production, check event.origin against Canvas domain
    
    if (event.data && event.data.subject === 'lti.frameResize') {
        // Canvas is requesting frame resize
        const height = document.body.scrollHeight;
        event.source.postMessage({
            subject: 'lti.frameResize',
            height: height
        }, event.origin);
    }
});
