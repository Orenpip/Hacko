# Canvas Addon - Resume & Transcript Upload Feature

This package adds the ability to upload resumes and transcripts within your Canvas addon.

## Features

- ✅ Drag-and-drop file upload
- ✅ Click to browse file upload
- ✅ Support for PDF, DOC, and DOCX formats
- ✅ File size validation (max 5MB)
- ✅ Real-time file validation
- ✅ Canvas LTI integration
- ✅ Responsive design
- ✅ User-friendly interface

## Files Included

1. **file-upload-component.html** - Main HTML interface for file uploads
2. **file-upload.js** - Client-side JavaScript for handling uploads
3. **canvas-lti-integration.js** - Canvas LTI integration layer
4. **upload-api.js** - Backend API endpoint example (Node.js/Express)

## Installation

### Frontend Integration

1. **Add the HTML component to your Canvas addon:**

```html
<!-- In your main Canvas addon page -->
<iframe src="file-upload-component.html" width="100%" height="600px" frameborder="0"></iframe>
```

Or include the HTML directly in your addon's main page.

2. **Include the JavaScript files:**

```html
<script src="file-upload.js"></script>
<script src="canvas-lti-integration.js"></script>
```

3. **Update the upload endpoint in file-upload.js:**

```javascript
// Line ~170 in file-upload.js
const uploadUrl = 'https://your-domain.com/api/upload';
```

### Backend Setup

1. **Install required npm packages:**

```bash
npm install express multer
```

2. **Add the upload API to your Express server:**

```javascript
const express = require('express');
const uploadRouter = require('./upload-api');

const app = express();

// Configure CORS for Canvas
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'https://canvas.instructure.com');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

// Add upload routes
app.use('/api', uploadRouter);

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
```

3. **Create uploads directory:**

```bash
mkdir uploads
```

4. **Configure file storage (optional):**

For production, consider using cloud storage like AWS S3, Google Cloud Storage, or Azure Blob Storage instead of local file storage.

## Canvas LTI Configuration

### 1. Register Your LTI Tool in Canvas

1. Go to Canvas Admin → Developer Keys
2. Click "+ Developer Key" → "+ LTI Key"
3. Fill in the required information:
   - **Key Name**: Resume & Transcript Upload
   - **Redirect URIs**: Your addon's URL
   - **Method**: Manual Entry
   - **Title**: Resume & Transcript Upload
   - **Target Link URI**: https://your-domain.com/file-upload-component.html
   - **OpenID Connect Initiation Url**: https://your-domain.com/lti/login
   - **JWK Method**: Public JWK URL
   - **Public JWK URL**: https://your-domain.com/.well-known/jwks.json

### 2. Configure LTI Scopes

Enable the following scopes:
- `https://purl.imsglobal.org/spec/lti-ags/scope/lineitem`
- `https://purl.imsglobal.org/spec/lti-ags/scope/result.readonly`
- `https://purl.imsglobal.org/spec/lti-ags/scope/score`

### 3. Add to Course

1. In your course, go to Settings → Apps
2. Click "View App Configurations"
3. Click "+ App"
4. Select "By Client ID"
5. Enter your Developer Key Client ID
6. Click "Submit"

## Usage

### Basic Usage

Students can:
1. Click on the upload areas or drag files
2. Upload their resume (PDF, DOC, or DOCX)
3. Upload their transcript (PDF, DOC, or DOCX)
4. Click "Upload Documents" to submit

### Programmatic Access

```javascript
// Get uploaded files for a user
fetch('/api/files/USER_ID')
    .then(response => response.json())
    .then(data => console.log(data));

// Delete a file
fetch('/api/files/FILE_ID', { method: 'DELETE' })
    .then(response => response.json())
    .then(data => console.log(data));
```

## Customization

### Styling

Modify the CSS in `file-upload-component.html` to match your Canvas theme:

```css
.upload-container {
    /* Customize container styles */
}

.submit-button {
    background: #YOUR_COLOR; /* Change button color */
}
```

### File Types

To support additional file types, update the allowed extensions:

```javascript
// In file-upload.js
this.allowedExtensions = ['pdf', 'doc', 'docx', 'txt', 'rtf'];
```

```javascript
// In upload-api.js
const allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
];
```

### File Size Limit

Change the maximum file size:

```javascript
// In file-upload.js (line ~4)
this.maxFileSize = 10 * 1024 * 1024; // 10MB

// In upload-api.js (line ~43)
limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
}
```

## Security Considerations

1. **Validate files on the server side** - Never trust client-side validation alone
2. **Scan uploaded files** - Use antivirus scanning for uploaded files
3. **Store files securely** - Don't serve uploaded files directly from the upload directory
4. **Authenticate requests** - Verify Canvas LTI tokens before allowing uploads
5. **Rate limiting** - Implement rate limiting to prevent abuse
6. **HTTPS only** - Always use HTTPS in production

## Database Schema

Suggested database schema for storing file records:

```sql
CREATE TABLE uploaded_files (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id VARCHAR(255) NOT NULL,
    course_id VARCHAR(255),
    file_type ENUM('resume', 'transcript') NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_course_id (course_id)
);
```

## Troubleshooting

### Files not uploading

1. Check browser console for errors
2. Verify the API endpoint URL is correct
3. Check CORS configuration
4. Verify file size is under the limit

### Canvas LTI issues

1. Verify Developer Key is enabled
2. Check LTI configuration settings
3. Ensure redirect URIs are correct
4. Check Canvas error logs

### File permissions

Ensure the uploads directory has proper write permissions:

```bash
chmod 755 uploads
```

## API Endpoints

### POST /api/upload
Upload resume and/or transcript files

**Request:**
- Content-Type: multipart/form-data
- Body: FormData with files

**Response:**
```json
{
    "success": true,
    "message": "Files uploaded successfully",
    "data": {
        "resume": {...},
        "transcript": {...}
    }
}
```

### GET /api/files/:userId
Get all uploaded files for a user

**Response:**
```json
{
    "success": true,
    "data": [...]
}
```

### DELETE /api/files/:fileId
Delete a specific file

**Response:**
```json
{
    "success": true,
    "message": "File deleted successfully"
}
```

## Future Enhancements

- [ ] PDF preview functionality
- [ ] Resume parsing and analysis
- [ ] Transcript GPA calculation
- [ ] Multi-file upload
- [ ] Cloud storage integration (S3, GCS, Azure)
- [ ] File versioning
- [ ] Sharing files with instructors
- [ ] OCR for scanned documents

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Canvas API documentation
3. Check server logs for errors

## License

Include your license information here.
