// File Upload Handler for Canvas Addon
class FileUploadManager {
    constructor() {
        this.resumeFile = null;
        this.transcriptFile = null;
        this.maxFileSize = 5 * 1024 * 1024; // 5MB
        this.allowedExtensions = ['pdf', 'doc', 'docx'];
        
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Resume upload
        this.setupFileInput('resume');
        this.setupFileInput('transcript');
        
        // Form submission
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSubmit();
        });
    }

    setupFileInput(type) {
        const uploadArea = document.getElementById(`${type}UploadArea`);
        const fileInput = document.getElementById(`${type}Input`);
        const removeButton = document.getElementById(`remove${this.capitalize(type)}`);

        // Click to upload
        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                this.handleFile(file, type);
            }
        });

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const file = e.dataTransfer.files[0];
            if (file) {
                this.handleFile(file, type);
            }
        });

        // Remove file
        removeButton.addEventListener('click', (e) => {
            e.stopPropagation();
            this.removeFile(type);
        });
    }

    handleFile(file, type) {
        // Validate file
        const validation = this.validateFile(file);
        
        if (!validation.valid) {
            this.showError(type, validation.error);
            return;
        }

        // Clear any previous errors
        this.clearError(type);

        // Store file
        if (type === 'resume') {
            this.resumeFile = file;
        } else {
            this.transcriptFile = file;
        }

        // Update UI
        this.updateFileInfo(file, type);
        this.updateSubmitButton();
    }

    validateFile(file) {
        // Check file size
        if (file.size > this.maxFileSize) {
            return {
                valid: false,
                error: 'File size exceeds 5MB limit'
            };
        }

        // Check file extension
        const extension = file.name.split('.').pop().toLowerCase();
        if (!this.allowedExtensions.includes(extension)) {
            return {
                valid: false,
                error: 'Invalid file format. Please upload PDF, DOC, or DOCX'
            };
        }

        return { valid: true };
    }

    updateFileInfo(file, type) {
        const fileInfo = document.getElementById(`${type}FileInfo`);
        const fileName = document.getElementById(`${type}FileName`);
        const fileSize = document.getElementById(`${type}FileSize`);

        fileName.textContent = file.name;
        fileSize.textContent = this.formatFileSize(file.size);
        fileInfo.classList.add('show');
    }

    removeFile(type) {
        if (type === 'resume') {
            this.resumeFile = null;
        } else {
            this.transcriptFile = null;
        }

        // Reset file input
        document.getElementById(`${type}Input`).value = '';

        // Hide file info
        document.getElementById(`${type}FileInfo`).classList.remove('show');

        // Clear errors
        this.clearError(type);

        // Update submit button
        this.updateSubmitButton();
    }

    showError(type, message) {
        const errorElement = document.getElementById(`${type}Error`);
        errorElement.textContent = message;
        errorElement.classList.add('show');
    }

    clearError(type) {
        const errorElement = document.getElementById(`${type}Error`);
        errorElement.textContent = '';
        errorElement.classList.remove('show');
    }

    updateSubmitButton() {
        const submitButton = document.getElementById('submitButton');
        // Enable button if at least one file is uploaded
        submitButton.disabled = !(this.resumeFile || this.transcriptFile);
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    async handleSubmit() {
        const submitButton = document.getElementById('submitButton');
        submitButton.disabled = true;
        submitButton.textContent = 'Uploading...';

        try {
            // Create FormData object
            const formData = new FormData();
            
            if (this.resumeFile) {
                formData.append('resume', this.resumeFile);
            }
            
            if (this.transcriptFile) {
                formData.append('transcript', this.transcriptFile);
            }

            // Add any additional metadata
            formData.append('uploadDate', new Date().toISOString());
            formData.append('userId', this.getUserId()); // Get from Canvas LTI

            // Upload to server
            const response = await this.uploadFiles(formData);

            if (response.success) {
                this.showSuccess();
                // Reset form after 2 seconds
                setTimeout(() => {
                    this.resetForm();
                }, 2000);
            } else {
                throw new Error(response.message || 'Upload failed');
            }

        } catch (error) {
            alert('Upload failed: ' + error.message);
            submitButton.disabled = false;
            submitButton.textContent = 'Upload Documents';
        }
    }

    async uploadFiles(formData) {
        // Replace this URL with your actual upload endpoint
        const uploadUrl = '/api/upload'; // Update this to your Canvas addon API endpoint

        try {
            const response = await fetch(uploadUrl, {
                method: 'POST',
                body: formData,
                // Add any necessary headers (e.g., authentication tokens)
                headers: {
                    // 'Authorization': 'Bearer ' + this.getAuthToken(),
                }
            });

            if (!response.ok) {
                throw new Error('Upload request failed');
            }

            return await response.json();

        } catch (error) {
            console.error('Upload error:', error);
            throw error;
        }
    }

    getUserId() {
        // This should be retrieved from Canvas LTI context
        // For now, returning a placeholder
        return 'user_' + Math.random().toString(36).substr(2, 9);
    }

    getAuthToken() {
        // Retrieve authentication token from Canvas LTI
        // This is a placeholder - implement based on your auth system
        return localStorage.getItem('canvas_auth_token');
    }

    showSuccess() {
        const successMessage = document.getElementById('successMessage');
        successMessage.classList.add('show');
    }

    resetForm() {
        this.removeFile('resume');
        this.removeFile('transcript');
        
        const successMessage = document.getElementById('successMessage');
        successMessage.classList.remove('show');
        
        const submitButton = document.getElementById('submitButton');
        submitButton.textContent = 'Upload Documents';
    }
}

// Initialize the file upload manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new FileUploadManager();
});
