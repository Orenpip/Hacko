// server.js - Simple Express server for the Canvas file upload addon

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const uploadRouter = require('./upload-api');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS configuration for Canvas
const corsOptions = {
    origin: function (origin, callback) {
        // Allow Canvas domains and your development domain
        const allowedOrigins = [
            'https://canvas.instructure.com',
            'http://localhost:3000',
            'http://localhost:8080',
            // Add your Canvas instance domain here
            process.env.CANVAS_DOMAIN
        ].filter(Boolean);

        if (!origin || allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true
};

app.use(cors(corsOptions));

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname)));

// API routes
app.use('/api', uploadRouter);

// Main route - serve the upload component
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'file-upload-component.html'));
});

// LTI launch endpoint
app.post('/lti/launch', (req, res) => {
    // Handle LTI launch from Canvas
    // Validate LTI token, extract user context, etc.
    res.sendFile(path.join(__dirname, 'file-upload-component.html'));
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: err.message || 'Internal server error'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Canvas File Upload Addon server running on port ${PORT}`);
    console.log(`Access the upload interface at: http://localhost:${PORT}`);
});

module.exports = app;
