# Canvas Resume & Transcript Upload - Quick Start

## 📦 Files Included

### Frontend Files
1. **file-upload-component.html** - Main UI for file uploads with drag-and-drop
2. **file-upload.js** - Client-side logic for handling file uploads
3. **canvas-lti-integration.js** - Canvas LTI integration layer

### Backend Files
4. **upload-api.js** - Express API endpoints for file uploads
5. **server.js** - Main Express server configuration
6. **package.json** - Node.js dependencies

### Documentation
7. **README.md** - Complete feature documentation
8. **INTEGRATION_GUIDE.md** - Step-by-step integration instructions

## 🚀 Quick Start (5 minutes)

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your Canvas settings
```

### 3. Create Upload Directory
```bash
mkdir uploads
```

### 4. Start Server
```bash
npm start
```

### 5. Test Locally
Open browser to: `http://localhost:3000`

## 📋 Features

✅ Drag-and-drop file upload  
✅ Click to browse file selection  
✅ Support for PDF, DOC, DOCX  
✅ 5MB file size limit  
✅ Real-time validation  
✅ Canvas LTI integration  
✅ Responsive design  
✅ User-friendly interface  

## 🔧 Integration Options

### Option 1: Standalone Page
Add to your Canvas course as a separate LTI tool

### Option 2: Embedded Component
Integrate into existing page using iframe or direct inclusion

### Option 3: Custom Integration
Modify and extend for specific requirements

## 📝 Next Steps

1. Read **README.md** for complete feature documentation
2. Follow **INTEGRATION_GUIDE.md** for Canvas LTI setup
3. Customize styling to match your institution's branding
4. Configure database for persistent storage (optional)
5. Deploy to production server
6. Add to Canvas course

## 🛠️ Customization

### Change File Size Limit
```javascript
// file-upload.js (line 4)
this.maxFileSize = 10 * 1024 * 1024; // 10MB

// upload-api.js (line 43)
limits: { fileSize: 10 * 1024 * 1024 }
```

### Add More File Types
```javascript
// file-upload.js (line 5)
this.allowedExtensions = ['pdf', 'doc', 'docx', 'txt'];
```

### Change Colors
```css
/* file-upload-component.html */
.submit-button {
    background: #YOUR_COLOR;
}
```

## 🔒 Security Features

- Server-side file validation
- File size limits
- MIME type checking
- Secure file storage
- CORS protection
- Optional virus scanning

## 📊 File Structure

```
canvas-file-upload/
├── file-upload-component.html  # Frontend UI
├── file-upload.js             # Frontend logic
├── canvas-lti-integration.js  # LTI integration
├── upload-api.js              # Backend API
├── server.js                  # Express server
├── package.json               # Dependencies
├── .env.example              # Config template
├── README.md                 # Documentation
├── INTEGRATION_GUIDE.md      # Setup guide
└── uploads/                  # Upload directory
```

## 💡 Tips

- Test locally before deploying to production
- Use HTTPS in production (required for Canvas LTI)
- Configure CORS for your Canvas domain
- Implement rate limiting to prevent abuse
- Set up logging for monitoring
- Regular cleanup of old files

## 🐛 Troubleshooting

**Files not uploading?**
- Check console for errors
- Verify API endpoint URL
- Check file size and type

**CORS errors?**
- Update CORS settings in server.js
- Add Canvas domain to allowed origins

**Canvas LTI not working?**
- Verify Developer Key is enabled
- Check redirect URIs
- Review Canvas error logs

## 📚 Resources

- [Canvas LTI Documentation](https://canvas.instructure.com/doc/api/file.tools_intro.html)
- [Express.js Docs](https://expressjs.com/)
- [Multer Documentation](https://github.com/expressjs/multer)

## 🎯 Ready to Deploy?

Follow the complete deployment guide in **INTEGRATION_GUIDE.md**

---

Need help? Check the README.md or INTEGRATION_GUIDE.md for detailed instructions!
